import hashlib

name = 'sha256'
bit = '256'

myhashing = hashlib.sha256
