lyra2re-hash-python
=====================

Python module with STRAKS' hashing algorithm used by some other tools
