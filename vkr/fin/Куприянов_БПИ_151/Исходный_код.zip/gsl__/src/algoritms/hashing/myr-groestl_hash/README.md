Myr-Groestl Python hashing module 
