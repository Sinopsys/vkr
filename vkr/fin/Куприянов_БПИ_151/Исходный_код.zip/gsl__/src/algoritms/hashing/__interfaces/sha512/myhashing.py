import hashlib

name = 'sha512'
bit = '256'

myhashing = hashlib.sha512
