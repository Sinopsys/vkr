from keccak import keccak

name = 'keccak512'
bit - '512'

myhashing = keccak.Keccak512
