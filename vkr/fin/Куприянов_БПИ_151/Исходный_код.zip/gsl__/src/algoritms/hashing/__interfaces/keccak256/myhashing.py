from keccak import keccak

name = 'keccak256'
bit = '256'

myhashing = keccak.Keccak256
